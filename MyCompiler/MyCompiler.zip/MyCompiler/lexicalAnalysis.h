#include "intermediateCodeOptimization.h"

void setupKeywordValue(void);
char getAChar(FILE *in);
int searchKeyword(char *str);
void getSymbol(FILE *in, FILE *out);
void printSymbolList(FILE *out);
