#include "errorHandling.h"


void setupSymbolTable(void);
void symbolTabLocation(int i);
void symbolTabReLocation(void);